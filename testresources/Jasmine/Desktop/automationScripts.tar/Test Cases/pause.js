it("pause", async function() {
	// :User Injected Code Snippet [// - [2 lines]]
	var cf = kony.application.getCurrentForm();
		cf.TextField0a4c3a6ab89794c.text = 'Pause';
	// :End User Injected Code Snippet {be7d46ca-e514-2107-17c5-2a3e3b094f90}
});